package apple;

public class RoomVO {
	public Integer getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(Integer roomNo) {
		this.roomNo = roomNo;
	}
	public String getApple() {
		return apple;
	}
	public void setApple(String apple) {
		this.apple = apple;
	}
	public String getBanana() {
		return banana;
	}
	public void setBanana(String banana) {
		this.banana = banana;
	}
	public String getOrange() {
		return orange;
	}
	public void setOrange(String orange) {
		this.orange = orange;
	}
	
	@Override
	public String toString() {
		return "RoomVO [roomNo=" + roomNo + ", apple=" + apple + ", banana=" + banana + ", orange=" + orange + "]";
	}

	private Integer roomNo = null;
	private String apple = null;
	private String banana = null;
	private String orange = null;
	
	public String getHashtag() {
		return hashtag;
	}
	public void setHashtag(String hashtag) {
		this.hashtag = hashtag;
	}
	public String getRemoteAddr() {
		return remoteAddr;
	}
	public void setRemoteAddr(String remoteAddr) {
		this.remoteAddr = remoteAddr;
	}

	private String hashtag = null;
	private String remoteAddr = null;
}
