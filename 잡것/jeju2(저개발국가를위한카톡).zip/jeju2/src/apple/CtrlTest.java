package apple;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class CtrlTest 
{
	@ResponseBody
	@RequestMapping("/ping.abc2")
	public String ping() throws Exception {
		return this.toString();
	}
	
	@RequestMapping("/upload.abc2")
	public String upload() throws Exception {
		return "upload";
	}	
}