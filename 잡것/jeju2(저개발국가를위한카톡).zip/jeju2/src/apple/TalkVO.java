package apple;

public class TalkVO {
	public Integer getTalkNo() {
		return talkNo;
	}
	public void setTalkNo(Integer talkNo) {
		this.talkNo = talkNo;
	}
	public Integer getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(Integer roomNo) {
		this.roomNo = roomNo;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getTalkTime() {
		return talkTime;
	}
	public void setTalkTime(String talkTime) {
		this.talkTime = talkTime;
	}

	@Override
	public String toString() {
		return "TalkVO [talkNo=" + talkNo + ", roomNo=" + roomNo + ", role=" + role + ", content=" + content
				+ ", talkTime=" + talkTime + ", remoteAddr=" + remoteAddr + "]";
	}

	private Integer talkNo = null;
	private Integer roomNo = null;
	
	private String role = null;
	private String content = null;
	private String talkTime = null;
	
	public String getRemoteAddr() {
		return remoteAddr;
	}
	public void setRemoteAddr(String remoteAddr) {
		this.remoteAddr = remoteAddr;
	}
	private String remoteAddr = null;	
}
