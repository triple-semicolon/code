package apple;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class RowMapper_Talk implements RowMapper<TalkVO> {

	@Override
	public TalkVO mapRow(ResultSet rs, int arg1) throws SQLException {
		TalkVO vo = new TalkVO();
		vo.setTalkNo( rs.getInt("talk_no") );
		vo.setRoomNo( rs.getInt("room_no") );
		
		vo.setRole( rs.getString("role") );
		vo.setContent( rs.getString("content") );
		vo.setTalkTime( rs.getString("talk_time") );
		vo.setRemoteAddr( rs.getString("remote_addr") );		
		return vo;
	}

}
