package apple;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class RowMapper_Room implements RowMapper<RoomVO> {

	@Override
	public RoomVO mapRow(ResultSet rs, int arg1) throws SQLException {
		RoomVO vo = new RoomVO();
		vo.setRoomNo( rs.getInt("room_no") );
		vo.setApple(  rs.getString("apple") );
		vo.setBanana( rs.getString("banana") );
		vo.setOrange( rs.getString("orange") );		
		
		vo.setHashtag( rs.getString("hashtag") );
		vo.setRemoteAddr( rs.getString("remote_addr") );
		return vo;
	}

}
