package apple;

import java.net.InetAddress;

import javax.servlet.http.HttpServletRequest;

public class Util 
{
	public static String ip2color( String ip ) 
	{
		ip = ip.trim();
		
		char[] ab = {'0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f'};
		
		char[] cs = ip.toCharArray();
		StringBuffer sb = new StringBuffer();
		for( int i = 0 ; i < cs.length ; i++ ) {
			if( cs[i] != '.' ) {
				sb.append( cs[i] );
			}
		}
		
		long ip_val = Long.parseLong( sb.toString() );
		
		if( ip_val > ( 256L * 256L * 256L ) )
		{
			int[] color = new int[6];
			for( int i = 0 ; i < 6 ; i++ ) {
				color[i] = (int)( ip_val % 16L );
				
				//	�ʹ� ��ο���� �����ϸ� �������� ��������. ���� ��� ���ֱ� ���� ����
				if( color[i] < 5 ) {
					color[i] = color[i] + 5;
				}
				ip_val = ip_val / 16L;
			}

			StringBuffer sb2 = new StringBuffer("#");
			for( int i = 0 ; i < 6 ; i++ ) {
				sb2.append( ab[color[i]] );
			}
			return ( sb2.toString() );		
		}
		else if( (int)ip_val > ( 16 * 16 * 16 ) )
		{
			int ip_int = (int)ip_val;
			
			int[] color = new int[3];
			for( int i = 0 ; i < 3 ; i++ ) {
				color[i] = ip_int % 16;

				//	�ʹ� ��ο���� �����ϸ� �������� ��������. ���� ��� ���ֱ� ���� ����				
				if( color[i] < 5 ) {
					color[i] = color[i] + 5;
				}
				ip_int = ip_int / 16;
			}

			StringBuffer sb2 = new StringBuffer("#");
			for( int i = 0 ; i < 3 ; i++ ) {
				sb2.append( "aa" );
				sb2.append( ab[color[i]] );
			}
			return ( sb2.toString() );		
		}
		else {
			return "#aabbcc";
		}
	}
	
	public static String upload() {
		String t = System.getProperty("os.name");
		String upload = "/pukyung00/upload/";
		if( t.indexOf("indows") != -1 ) {
			upload = "C:\\upload\\";
		}
		return upload;
	}
	
	
	public static String han( String l ) {
		if( l == null || l.equals("") )
			return l;
		try {
			l = new String( l.getBytes("8859_1") , "utf-8");
		}
		catch( Exception e ) {}
		return l;
	}
	
	//	����24 ȯ�濡�� ������ Ŭ���̾�Ʈ�� ip �ּ� �����ϴ� �ڵ�
	public static String getRemoteAddr( HttpServletRequest request ) 
	{
		String t = System.getProperty("os.name");
		if( t.indexOf("indows") != -1 ) 
		{
			try {
				return InetAddress.getLocalHost().getHostAddress().toString();
			}
			catch( Exception e ) {
				return "127.0.0.1";
			}
		}
		
		String ip = request.getHeader("X-FORWARDED-FOR"); 
        if (ip == null || ip.length() == 0) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0) {
            ip = request.getHeader("HTTP_CLIENT_IP");     
        }
        if (ip == null || ip.length() == 0) {
            ip = request.getHeader("HTTP_X_FORWARDED_FOR"); 
        }
        if (ip == null || ip.length() == 0) {
            ip = request.getRemoteAddr() ;
        }
        return ip;
	} 	
}
