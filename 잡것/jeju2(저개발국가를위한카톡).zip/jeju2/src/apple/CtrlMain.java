package apple;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class CtrlMain 
{
	@Autowired
	private JdbcTemplate jtpl = null;
	
	@Autowired
	private TransactionTemplate txtpl = null;
	
	@RequestMapping("/login.abc2")
	public ModelAndView login( HttpSession session, 
		@RequestParam(value="roomNo",required=false) Integer roomNo,
		@RequestParam(value="ecode",required=false) String ecode,
		@RequestParam(value="doit",required=false) String doit ) throws Exception 
	{
		if( roomNo != null && session.getAttribute("role@"+roomNo) != null ) {
			session.removeAttribute("role");
		}
		
		ModelAndView mnv = new ModelAndView("login");
		if( doit != null && !doit.equals("") ) {
			mnv.addObject("doit", doit);
		}
		if( ecode != null ) {
			mnv.addObject("ecode", ecode);
		}
		return mnv;
	}
	
	@RequestMapping("/login2.abc2")
	public String login2( HttpSession session ,  
		@RequestParam("roomNo") Integer roomNo,
		@RequestParam("passwd") String passwd ) throws Exception 
	{
		try 
		{
			RoomVO vo = jtpl.queryForObject("select * from abc2_room_T where room_no = ?", 
				new RowMapper_Room(), roomNo );
			
			passwd = passwd.trim();	//	Ȥ�ó� ���� �� �ִ� ���� ���ſ�
			if( vo.getApple().equals( passwd ) ) {
				session.setAttribute("role@"+roomNo,"apple");
				return "redirect:talk_list.abc2?roomNo=" + roomNo;
			}
			else if( vo.getBanana().equals( passwd ) ){
				session.setAttribute("role@"+roomNo,"banana");
				return "redirect:talk_list.abc2?roomNo=" + roomNo;
			}	
			else if( vo.getOrange().equals( passwd ) ){
				session.setAttribute("role@"+roomNo,"orange");
				return "redirect:talk_list.abc2?roomNo=" + roomNo;
			}
			else {
				return "redirect:login.abc2?ecode=passwd_fail";
			}
		}
		catch( DataAccessException e ) {
			return "redirect:login.abc2?ecode=no_room";
		}
	}
	
	
	@RequestMapping("/room_make.abc2")
	public String roomAdd() throws Exception 
	{
		return "room_make";
	}	

/*
 * �ڵ����� �߻���Ű�� ��ȣ�� ��ġ�� �ʵ��� �߻���Ų ��ȣ�� ����ϴ� ���̺��� �����Ѵ�.
 * ���� ��ȭ���� ���ĵǴ� ��쿡�� �� ���̺��� �������� ��ȣ�� �����Ѵ�.

DROP TABLE abc2_passwd_T;
CREATE TABLE abc2_passwd_T (
	passwd CHAR(6) NOT NULL PRIMARY KEY
); 
*/	
	private static String cs = "QWERTYUIOPASDFGHJKLZXCVBNM";
	private static String is = "1234567890";

	private String generatePasswd() {
		StringBuffer sb = new StringBuffer();
		for( int i = 0 ; i < 6 ; i++ ) {
			if( i == 0 || i == 3 ) {
				int idx = (int)( Math.random() * cs.length() );
				sb.append( cs.charAt(idx));
			} else {
				int idx = (int)( Math.random() * is.length() );
				sb.append( is.charAt(idx));
			}
		}
		return sb.toString();
	}
	
	@RequestMapping("/room_make2.abc2")
	public String roomMake2( HttpServletRequest request ,  
		@RequestParam(value="hashtag",required=false) String hashtag ) 
		throws Exception 
	{
		final String remoteAddr = Util.getRemoteAddr(request);
		final String hashtag2 = ( hashtag != null && !hashtag.equals("") ) ? 
			hashtag + " " : null;
		
		final String[] passwds = new String[3];
		for( int i = 0 ; i < 3 ; i++ ) {
			passwds[i] = generatePasswd();	
		}
		
		TransactionCallback<Integer> action = new TransactionCallback<Integer>() {
			@Override
			public Integer doInTransaction(TransactionStatus status) {
				jtpl.update("insert into abc2_passwd_T values (?)", passwds[0] );
				jtpl.update("insert into abc2_passwd_T values (?)", passwds[1] );
				jtpl.update("insert into abc2_passwd_T values (?)", passwds[2] );
				jtpl.update("insert into abc2_room_T values (default,?,?,?,?,?)",
					passwds[0], passwds[1], passwds[2], hashtag2, remoteAddr );
				return jtpl.queryForObject("SELECT last_insert_id()",Integer.class);
			}
		};
		int lastInsertId = txtpl.execute(action);

		return "redirect:room_read.abc2?roomNo=" + lastInsertId;
	}
	
	@RequestMapping("/room_read.abc2")
	public ModelAndView roomRead( @RequestParam("roomNo") Integer roomNo ) 
		throws Exception 
	{
		RoomVO vo = jtpl.queryForObject("SELECT * FROM abc2_room_T where room_no = ?",
			new Object[] { roomNo } , new RowMapper_Room() );

		ModelAndView mnv = new ModelAndView("room_read");
		mnv.addObject("room",vo);
		return mnv;
	}	
	
	@RequestMapping("/room_find.abc2")
	public Object roomFind( final @RequestParam("hashtag") String hashtag ) 
		throws Exception 
	{
		List<RoomVO> rl = jtpl.query("SELECT * FROM abc2_room_T where hashtag LIKE ?",
			new RowMapper_Room() , "%"+hashtag+"%" );
		if( rl == null || rl.size() == 0 ) {
			return "redirect:login.abc2?ecode=no_hashtag";			
		}

		ModelAndView mnv = new ModelAndView("room_find");
		mnv.addObject("rl", rl );
		return mnv;
	}	
	
	@RequestMapping("/talk_list.abc2")
	public Object talkList( @ModelAttribute TalkVO pvo , 
		HttpSession session ) throws Exception 
	{
		String role = (String)session.getAttribute("role@"+pvo.getRoomNo());
		if( role == null ){
			return "redirect:login.abc2?ecode=need_login";
		}
		else if( !role.equals("apple") && !role.equals("banana") && !role.equals("orange") ) {
			return "redirect:login.abc2?ecode=need_login";
		} 
		
		List<TalkVO> rl = jtpl.query("select * from abc2_talk_T where room_no = ? order by talk_no ASC", 
			new RowMapper_Talk(), pvo.getRoomNo() );
		
		ModelAndView mnv = new ModelAndView("talk_list_" + role );
		mnv.addObject("role", role );
		mnv.addObject("rl",rl);
		mnv.addObject("pvo",pvo);
		return mnv;
	}	
	
	@RequestMapping("/talk_add2.abc2")
	public String talkAdd2( @ModelAttribute TalkVO pvo, HttpSession session,
		HttpServletRequest request ) throws Exception 
	{
		String role = (String)session.getAttribute("role@"+pvo.getRoomNo() );
		if( role == null ){
			return "redirect:login.abc2?ecode=need_login";
		}
		else if( !role.equals("apple") && !role.equals("banana") ) {
			return "redirect:login.abc2?ecode=need_login";			
		}
		
		pvo.setContent( Util.han( pvo.getContent() ) );
		int uc = jtpl.update("insert into abc2_talk_T values (default,?,?,?,NOW(),?)",
			pvo.getRoomNo(),pvo.getRole(), pvo.getContent(), Util.getRemoteAddr(request) );
		return "redirect:talk_list.abc2?roomNo=" + pvo.getRoomNo();
	}	
	
	@RequestMapping("/talk_del2.abc2")
	public String talkDel2( @ModelAttribute TalkVO pvo, HttpSession session ) 
		throws Exception 
	{
		String role = (String)session.getAttribute("role@"+pvo.getRoomNo());
		if( role == null ){
			return "redirect:login.abc2?ecode=need_login";
		}
		else if( !role.equals("apple") ) {
			return "redirect:login.abc2?ecode=need_login";
		}
		
		int uc = jtpl.update("delete from abc2_talk_T where talk_no=? and room_no=?",
			pvo.getTalkNo(), pvo.getRoomNo() );
		if( uc > 0 ) {
			return "redirect:talk_list.abc2?roomNo=" + pvo.getRoomNo();
		} else {
			return "redirect:login.abc2?ecode=no_del_right";
		}
	}	

	@RequestMapping("/room_del2.abc2")
	public String roomDel2( HttpSession session,
		final @RequestParam("roomNo") Integer roomNo ) throws Exception 
	{
		String role = (String)session.getAttribute("role@"+ roomNo );
		if( role == null ){
			return "redirect:login.abc2?ecode=need_login";
		}
		else if( !role.equals("apple") ) {
			return "redirect:login.abc2?ecode=need_login";
		}
		
		int uc = txtpl.execute( new TransactionCallback<Integer>() {
			@Override
			public Integer doInTransaction(TransactionStatus status) 
			{
				RoomVO vo = jtpl.queryForObject("select * from abc2_room_T where room_no=?", 
					new RowMapper_Room(), roomNo );
				
				jtpl.update("delete from abc2_talk_T where room_no=?", roomNo );
				int uc = jtpl.update("delete from abc2_room_T where room_no=?", roomNo );
				if( vo != null && uc > 0 ) {
					jtpl.update("delete from abc2_passwd_T where passwd in (?,?,?)", 
						vo.getApple(), vo.getBanana(), vo.getOrange() );
				}
				return uc;
			}
		});
		
		if( uc > 0 ) {
			session.removeAttribute( "role@"+ roomNo );
			return "redirect:login.abc2?ecode=del_success";
		} else {
			return "redirect:login.abc2?ecode=no_del_right";
		}
	}	
}